PROVIDELABS ID SYSTEM - BATCH 9-UP ID PRINTING

WHAT THIS ADDS
==============
Admin users can select cardholders and generate:
- Selected Front IDs
- Selected Back IDs

OUTPUT
======
- US Letter landscape
- 3 columns x 3 rows
- Up to 9 IDs per page
- Additional pages for more than 9 selected
- Blank unused slots on the final page
- Front and back generated separately
- Same selected order on both sides
- School is not printed on Sangguniang Kabataan IDs
- Batch printing does not change cardholder status

FILES
=====
ADD:
app/Http/Controllers/Admin/CardholderBatchPrintController.php

ADD:
resources/views/admin/cardholders/batch-print.blade.php

ADD:
public/assets/admin-batch-card-print.js

ADD:
routes/admin-cardholder-print.php

REPLACE:
resources/views/admin/cardholders/index.blade.php

EDIT:
routes/web.php

ROUTES/WEB.PHP
==============
At the bottom, keep your existing admin route include and add:

require __DIR__.'/admin-cardholders.php';
require __DIR__.'/admin-cardholder-print.php';

Do not duplicate admin-cardholders.php if it already exists.

VERIFY
======
php artisan route:list --name=admin.cardholders.batch-print

Expected:
POST admin/cardholders/batch-print/{side}

If optimize:clear hits your local SQLite cache issue, use:

CACHE_STORE=file php artisan optimize:clear

PRINT SETTINGS
==============
Paper: Letter
Orientation: Landscape
Scale: 100%
Margins: None
Headers/footers: Off
Background graphics: On

GIT
===
git status
git add app/Http/Controllers/Admin/CardholderBatchPrintController.php
git add resources/views/admin/cardholders/batch-print.blade.php
git add resources/views/admin/cardholders/index.blade.php
git add public/assets/admin-batch-card-print.js
git add routes/admin-cardholder-print.php
git add routes/web.php
git commit -m "Add batch 9-up ID printing"
git pull --rebase origin main
git push origin main

MODEL RELATIONSHIP
==================
The controller expects Cardholder to have:

public function cardType()
{
    return $this->belongsTo(CardType::class);
}

If your relationship method uses another name, update:
with('cardType')
and:
$cardholder->cardType

TEMPLATES
=========
The renderer expects:

public/assets/card-templates/{card-type-slug}/front.png
public/assets/card-templates/{card-type-slug}/back.png

Examples:
public/assets/card-templates/senior-citizen-card/front.png
public/assets/card-templates/senior-citizen-card/back.png
public/assets/card-templates/sangguniang-kabataan/front.png
public/assets/card-templates/sangguniang-kabataan/back.png

NOTE
====
The batch renderer contains the Senior Citizen and Sangguniang Kabataan
drawing coordinates used in the generator we built earlier. If you later
fine-tune public/assets/card-generator.js, make the same coordinate changes
in public/assets/admin-batch-card-print.js so the two stay visually aligned.
