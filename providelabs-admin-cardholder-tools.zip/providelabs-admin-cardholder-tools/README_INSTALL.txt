PROVIDELABS ID SYSTEM - ADMIN CARDHOLDER TOOLS

WHAT THIS ADDS
==============
1. Download the complete cardholder record list as one CSV.
2. Batch-assign statuses to selected cardholders.
3. Search and filter the admin cardholder list.
4. Sort by ID Number, Name, Status, Position, Birthdate, and Date Created.
5. Admin-only server-side authorization.

FILES TO ADD
============
Copy these files into the exact same paths in your Laravel project:

app/Http/Controllers/Admin/CardholderManagementController.php
resources/views/admin/cardholders/index.blade.php
routes/admin-cardholders.php

ONE EXISTING FILE TO EDIT
=========================
Open:

routes/web.php

Add this line at the VERY BOTTOM:

require __DIR__.'/admin-cardholders.php';

Do not replace your existing routes/web.php.

VERIFY IN CODESPACES
====================
Run:

php artisan optimize:clear
php artisan route:list --name=admin.cardholders

You should see:

admin.cardholders.manage
admin.cardholders.export-csv
admin.cardholders.batch-status

Then log in as an administrator and open:

/admin/cardholders/manage

CSV EXPORT
==========
The CSV always exports the COMPLETE cardholder record list, regardless
of the current filters or page.

Included columns:

ID NO
CARD TYPE
NAME
SC ID
PHILHEALTH
CONTACT NO
POSITION
SCHOOL (when the column exists)
ADDRESS
BIRTHDATE
AGE
CONTACT PERSON
EMERGENCY NO
RELATIONSHIP
STATUS
DATE CREATED
DATE GENERATED
DATE PRINTED
DATE RELEASED

BATCH STATUS
============
The included statuses are:

pending
generated
printed
released

When changing a record to generated, printed, or released, the matching
timestamp is filled only if it is currently empty. Existing timestamps
are not overwritten.

GIT COMMANDS
============
After copying the files and editing routes/web.php:

git status
git add app/Http/Controllers/Admin/CardholderManagementController.php
git add resources/views/admin/cardholders/index.blade.php
git add routes/admin-cardholders.php
git add routes/web.php
git commit -m "Add admin cardholder management tools"
git pull --rebase origin main
git push origin main

Then deploy the latest commit in Laravel Cloud.

IMPORTANT
=========
This is an additive module. It does not replace CardholderController.php
and does not modify the Senior Citizen or Sangguniang Kabataan card
generation workflow.

It assumes your administrator role is stored as:

admin

It also assumes your current workflow statuses are:

pending
generated
printed
released
